module CNovaApiLojistaV2
  module Client
    VERSION = "1.0.0"
  end
end
